﻿namespace ASCOM.DSLR.Enums
{
    public enum CameraMode
    {
        RGGB = 0,
        Color16 = 1,
        ColorJpg = 3
    }
}