﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASCOM.DSLR.Enums
{
    public enum ConnectionMethod
    {
        CanonSdk = 0,
        BackyardEOS = 1
    }
}
