﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASCOM.DSLR.Enums
{
    public enum ImageFormat
    {
        RAW = 0,
        JPEG = 1
    }
}
