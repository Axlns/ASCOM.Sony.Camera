﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASCOM.DSLR.Enums
{
    public enum LiveViewZoom
    {
        Fit = 1,
        x5 = 5,
        x10 = 10
    }
}
