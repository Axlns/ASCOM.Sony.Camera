﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EDSDKLib.API.Base
{
    public class CanceledFlag
    {
        public bool IsCanceled = false;
    }
}
